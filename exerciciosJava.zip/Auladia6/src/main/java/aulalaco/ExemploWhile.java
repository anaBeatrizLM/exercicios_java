package aulalaco;

public class ExemploWhile {

	public static void main(String[] args) {
		int n = 0;
		
		while(n<=10) {
			System.out.println(n);
			n+=2;
		}

	}

}
