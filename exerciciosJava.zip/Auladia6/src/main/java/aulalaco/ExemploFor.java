package aulalaco;

import java.util.Scanner;

public class ExemploFor {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		
		int par = 0;
		int impar = 0;
		
		for(int n=1; n<=10; n++) {
			System.out.println("digite um n�mero: ");
			int numero = entrada.nextInt();
			
			if(numero %2 ==0) {
				System.out.println("Esse � um n�mero par");
				par = par + 1;
			}
			else {
				System.out.println("Esse � um n�mero �mpar");
				impar = impar + 1;
			}
		}
		System.out.println("n�meros pares: "+par);
		System.out.println("n�meros �mpares: "+impar);

	}

}
