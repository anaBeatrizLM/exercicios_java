package aulacondicional;

public class Calculo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
