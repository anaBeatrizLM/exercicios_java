package aulacondicional;

public class MesesDoAno {

	public static void main(String[] args) {
		int MesDoAno = 5;
		String NomeMes;
		
		switch(MesDoAno) {
		
		case 1: NomeMes="Janeiro";break;
		case 2: NomeMes="Fevereiro";break;
		case 3: NomeMes="Mar�o";break;
		case 4: NomeMes="Abril";break;
		case 5: NomeMes="Maio";break;
		case 6: NomeMes="Junho";break;
		case 7: NomeMes="Julho";break;
		case 8: NomeMes="Agosto";break;
		case 9: NomeMes="Setembro";break;
		case 10: NomeMes="Outubro";break;
		case 11: NomeMes="Novembro";break;
		case 12: NomeMes="Dezembro";break;
		default: NomeMes="M�s inv�lido";
		}
		System.out.println(NomeMes);

	}
}


	
