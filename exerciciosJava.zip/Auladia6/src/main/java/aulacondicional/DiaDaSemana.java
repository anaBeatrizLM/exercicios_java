package aulacondicional;

public class DiaDaSemana {

	public static void main(String[] args) {
		int DiaDaSemana = 5;
		String NomeDia;
		
		switch(DiaDaSemana) {
		
		case 1: NomeDia="Domingo";break;
		case 2: NomeDia="Segunda";break;
		case 3: NomeDia="Ter�a";break;
		case 4: NomeDia="Quarta";break;
		case 5: NomeDia="Quinta";break;
		case 6: NomeDia="Sexta";break;
		case 7: NomeDia="Sab�do";break;
		default: NomeDia="Dia inv�lido";
		}
		System.out.println(NomeDia);

	}

}
