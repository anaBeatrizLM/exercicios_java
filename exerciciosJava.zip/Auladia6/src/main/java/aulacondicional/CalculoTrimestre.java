package aulacondicional;

import java.util.Scanner;

public class CalculoTrimestre {

	public static void main(String[] args) {
		Scanner leitor = new Scanner(System.in);
		
		System.out.println("Digite o valor dos gastos de Janeiro: ");
		double janeiro = leitor.nextDouble();
		
		System.out.println("Digite o valor dos gastos de Fevereiro: ");
		double fevereiro = leitor.nextDouble();
		
		System.out.println("Digite o valor dos gastos de Mar�o: ");
		double marco = leitor.nextDouble();
		
		double total;
		total = janeiro+fevereiro+marco;
		System.out.println("O total dos gastos nesse trimestre �: "+total);
		
		double media;
		media = total / 3;
		System.out.println("A m�dia dos gastos nesse trimestre �: "+media);
		
		if(media >20000) {
			System.out.println("Iniciar corte de gastos");
		}
		else {
			System.out.println("Gastos dentro do esperado");
		}

	}

}
