module Auladia7 {
}