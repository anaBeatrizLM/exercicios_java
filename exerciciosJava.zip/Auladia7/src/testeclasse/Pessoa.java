package testeclasse;

public class Pessoa {

		public String nome;
		public int id;
		public String data;
		public String doc;
		public String cidade;

	}

