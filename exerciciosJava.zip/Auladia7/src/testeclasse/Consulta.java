package testeclasse;

public class Consulta {
	public int id;
	public int id_paciente;
	public int id_medico;
	
	public void VerConsulta() {
		System.out.println("A indentifica��o do paciente: " + this.id_paciente + "\n" + "A indentifica��o do m�dico: " + this.id_medico);
		
	}
}
