package testeclasse;

public class ImprimeConsulta {

	public static void main(String[] args) {
		Paciente Debora = new Paciente();
		Paciente Ana = new Paciente();
		Medico DrJorge = new Medico();
		Medico DrMauro = new Medico();
		Consulta consulta1 = new Consulta();
		Consulta consulta2 = new Consulta();
		
		Debora.id = 456;
		DrJorge.id = 234;
		
		Ana.id = 200;
		DrMauro.id = 100;
		
		consulta1.id_paciente = Debora.id;
		consulta1.id_medico = DrJorge.id;
		
		consulta2.id_paciente = Ana.id;
		consulta2.id_medico = DrMauro.id;
		
		consulta1.VerConsulta();
		consulta2.VerConsulta();

	}

}
