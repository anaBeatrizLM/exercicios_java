package testeclasse;

public class Medico extends Pessoa{
	public String CRM;
}
