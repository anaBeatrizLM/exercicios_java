package testeclasse;

public class Funcionario extends Pessoa{
	public String matricula;
}
