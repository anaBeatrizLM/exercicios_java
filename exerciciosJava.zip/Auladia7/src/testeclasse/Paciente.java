package testeclasse;

public class Paciente extends Pessoa{
	public String CPF;
}
